# AkFileCl
Deep-blue file manager (Akula + Claude). Zip/7z/tar compress & extract, favorites, Shizuku connect.
Push to GitHub -> Actions tab -> "Build AkFileCl APK" -> download the APK artifact.
