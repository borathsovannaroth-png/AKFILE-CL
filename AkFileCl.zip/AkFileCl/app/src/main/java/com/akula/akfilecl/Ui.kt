package com.akula.akfilecl

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt

private val Navy = Color(0xFF0A1B33)
private val Panel = Color(0xFF10294D)
private val Accent = Color(0xFF4C9AFF)
private val Txt = Color(0xFFE6EEF9)
private val Dim = Color(0xFFA9BCD8)

@Composable
fun AkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Navy, background = Navy, onBackground = Txt,
            surface = Panel, onSurface = Txt, surfaceVariant = Panel, onSurfaceVariant = Dim,
            surfaceContainer = Panel, surfaceContainerHigh = Panel, surfaceContainerLow = Panel,
            secondaryContainer = Color(0xFF1B4A8A)
        ),
        content = content
    )
}

sealed class Dlg {
    data class Rename(val f: File) : Dlg()
    data class Delete(val f: File) : Dlg()
    data class Info(val f: File) : Dlg()
    data class Compress(val f: File) : Dlg()
    data class View(val f: File) : Dlg()
    data class ExtractTo(val f: File) : Dlg()
    object Shizuku : Dlg()
    object Favs : Dlg()
}

private fun shizukuState(): String = try {
    if (!Shizuku.pingBinder()) "Shizuku is not running"
    else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "Connected to Shizuku"
    else "Shizuku running - permission needed"
} catch (e: Throwable) { "Shizuku not installed" }

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AkApp(act: ComponentActivity) {
    val ctx = act
    val scope = rememberCoroutineScope()
    val root = remember { Environment.getExternalStorageDirectory() }
    val prefs = remember { ctx.getSharedPreferences("ak", 0) }
    var dir by remember { mutableStateOf(root) }
    var tick by remember { mutableIntStateOf(0) }
    var showCredit by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf<File?>(null) }
    var sheet by remember { mutableStateOf<File?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var clip by remember { mutableStateOf<Pair<List<File>, Boolean>?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }

    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }

    val hasAccess = remember(tick) {
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }
    val items = remember(dir, tick, hasAccess) {
        (dir.listFiles()?.toList() ?: emptyList())
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }

    BackHandler(enabled = dir != root) { dir.parentFile?.let { dir = it } }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun runOp(ok: String, block: () -> Unit) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching(block) }
            toast(r.fold({ ok }, { "Error: ${it.message}" }))
            tick++
        }
    }
    fun closeMenus() { menu = null; sheet = null }
    fun quick(f: File, fmt: String) {
        val base = if (f.isDirectory) f.name else f.nameWithoutExtension
        val out = Archiver.unique(File(f.parentFile, "$base.$fmt"))
        runOp("Created ${out.name}") { Archiver.compress(listOf(f), out, fmt) }
        closeMenus()
    }
    fun uri(f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", f)
    fun mime(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    fun openFile(f: File) {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri(f), mime(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }.onFailure { toast("No app can open this file") }
        closeMenus()
    }
    fun share(f: File) {
        runCatching {
            val i = Intent(Intent.ACTION_SEND).setType(mime(f)).putExtra(Intent.EXTRA_STREAM, uri(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, "Share"))
        }
        closeMenus()
    }
    fun paste() {
        val c = clip ?: return
        val target = dir
        runOp("Pasted") {
            c.first.forEach {
                val t = Archiver.unique(File(target, it.name))
                if (c.second) { if (!it.renameTo(t)) { it.copyRecursively(t); it.deleteRecursively() } }
                else it.copyRecursively(t)
            }
        }
        if (c.second) clip = null
    }
    fun setFavs(s: Set<String>) { favs = s; prefs.edit().putStringSet("favs", s).apply() }

    Scaffold(
        containerColor = Navy,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Panel, titleContentColor = Txt,
                    navigationIconContentColor = Txt, actionIconContentColor = Txt),
                title = {
                    Column {
                        Text("AkFileCl", fontWeight = FontWeight.Bold)
                        Text(dir.path, fontSize = 11.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = {
                    if (dir != root) IconButton({ dir.parentFile?.let { dir = it } }) {
                        Icon(Icons.Filled.ArrowUpward, "Up")
                    }
                },
                actions = {
                    if (clip != null) IconButton({ paste() }) { Icon(Icons.Filled.ContentPaste, "Paste") }
                    IconButton({ dlg = Dlg.Favs }) { Icon(Icons.Filled.Star, "Favorites") }
                    IconButton({ dlg = Dlg.Shizuku }) { Icon(Icons.Filled.Bolt, "Shizuku") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (!hasAccess) {
                Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AkFileCl needs file access to manage your files.", color = Txt, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Button({
                        if (Build.VERSION.SDK_INT >= 30) {
                            ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:${ctx.packageName}")))
                        } else ctx.requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
                    }) { Text("Grant access") }
                }
            } else if (items.isEmpty()) {
                Text("Empty folder", color = Dim, modifier = Modifier.align(Alignment.Center))
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(items, key = { it.path }) { f ->
                        Row(
                            Modifier.fillMaxWidth()
                                .combinedClickable(
                                    onClick = { if (f.isDirectory) dir = f else sheet = f },
                                    onLongClick = { menu = f })
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                when {
                                    f.isDirectory -> Icons.Filled.Folder
                                    Archiver.isArchive(f) -> Icons.Filled.Archive
                                    else -> Icons.Filled.InsertDriveFile
                                }, null, tint = if (f.isDirectory) Accent else Dim, modifier = Modifier.size(36.dp)
                            )
                            Spacer(Modifier.width(16.dp))
                            Column {
                                Text(f.name, color = Txt, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (f.isDirectory) "${f.listFiles()?.size ?: 0} items"
                                    else Formatter.formatFileSize(ctx, f.length()),
                                    color = Dim, fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // ---- Long-press menu (folder / file) ----
    menu?.let { f ->
        ModalBottomSheet(onDismissRequest = { menu = null }, containerColor = Panel) {
            Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding()) {
                SheetTitle(f.name)
                if (f.isDirectory) {
                    MenuItem(Icons.Filled.Archive, "Compress to *.zip") { quick(f, "zip") }
                    MenuItem(Icons.Filled.Archive, "Compress to *.7z") { quick(f, "7z") }
                } else {
                    MenuItem(Icons.Filled.Visibility, "Open as archive") { dlg = Dlg.View(f); closeMenus() }
                }
                MenuItem(Icons.Filled.Archive, "Compress...") { dlg = Dlg.Compress(f); closeMenus() }
                if (!f.isDirectory) MenuItem(Icons.Filled.Info, "Information") { dlg = Dlg.Info(f); closeMenus() }
                MenuItem(Icons.Filled.ContentCopy, "Copy") { clip = listOf(f) to false; toast("Copied"); closeMenus() }
                MenuItem(Icons.Filled.ContentCut, "Cut") { clip = listOf(f) to true; toast("Cut"); closeMenus() }
                MenuItem(Icons.Filled.Delete, "Delete") { dlg = Dlg.Delete(f); closeMenus() }
                MenuItem(Icons.Filled.Edit, "Rename") { dlg = Dlg.Rename(f); closeMenus() }
                if (f.isDirectory) {
                    MenuItem(Icons.Filled.Info, "Information") { dlg = Dlg.Info(f); closeMenus() }
                    if (f.path in favs) MenuItem(Icons.Filled.StarBorder, "Remove from Favorites") { setFavs(favs - f.path); closeMenus() }
                    else MenuItem(Icons.Filled.Star, "Add to Favorites") { setFavs(favs + f.path); toast("Added to Favorites"); closeMenus() }
                } else MenuItem(Icons.Filled.Share, "Share") { share(f) }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // ---- Single-tap sheet (archive / other file) ----
    sheet?.let { f ->
        ModalBottomSheet(onDismissRequest = { sheet = null }, containerColor = Panel) {
            Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding()) {
                SheetTitle(f.name)
                if (Archiver.isArchive(f)) {
                    MenuItem(Icons.Filled.Visibility, "View") { dlg = Dlg.View(f); closeMenus() }
                    MenuItem(Icons.Filled.Unarchive, "Extract here") {
                        runOp("Extracted") { Archiver.extract(f, f.parentFile!!) }; closeMenus()
                    }
                    MenuItem(Icons.Filled.Unarchive, "Extract to ./<Archive name>/") {
                        runOp("Extracted") { Archiver.extract(f, File(f.parentFile, f.nameWithoutExtension)) }; closeMenus()
                    }
                    MenuItem(Icons.Filled.Unarchive, "Extract...") { dlg = Dlg.ExtractTo(f); closeMenus() }
                    MenuItem(Icons.Filled.CheckBox, "Test") {
                        runOp("Archive is OK") { Archiver.test(f, ctx.cacheDir) }; closeMenus()
                    }
                    MenuItem(Icons.Filled.Archive, "Compress...") { dlg = Dlg.Compress(f); closeMenus() }
                } else {
                    MenuItem(Icons.Filled.Visibility, "Open") { openFile(f) }
                    MenuItem(Icons.Filled.Archive, "Compress to *.zip") { quick(f, "zip") }
                    MenuItem(Icons.Filled.Archive, "Compress to *.7z") { quick(f, "7z") }
                    MenuItem(Icons.Filled.Archive, "Compress...") { dlg = Dlg.Compress(f); closeMenus() }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // ---- Dialogs ----
    when (val d = dlg) {
        null -> {}
        is Dlg.Rename -> TextDlg("Rename", d.f.name, { dlg = null }) { n ->
            if (n.isNotEmpty()) runOp("Renamed") { if (!d.f.renameTo(File(d.f.parentFile, n))) error("Rename failed") }
            dlg = null
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Delete") }, text = { Text("Delete \"${d.f.name}\"? This cannot be undone.") },
            confirmButton = { TextButton({ runOp("Deleted") { d.f.deleteRecursively() }; dlg = null }) { Text("Delete") } },
            dismissButton = { TextButton({ dlg = null }) { Text("Cancel") } })
        is Dlg.ExtractTo -> TextDlg("Extract to", d.f.parent ?: "", { dlg = null }) { p ->
            runOp("Extracted") { Archiver.extract(d.f, File(p)) }; dlg = null
        }
        is Dlg.Compress -> CompressDlg(d.f, { dlg = null }) { name, fmt ->
            val out = Archiver.unique(File(d.f.parentFile, "$name.$fmt"))
            runOp("Created ${out.name}") { Archiver.compress(listOf(d.f), out, fmt) }; dlg = null
        }
        is Dlg.Info -> {
            val size by produceState("Calculating...", d) {
                value = withContext(Dispatchers.IO) {
                    Formatter.formatFileSize(ctx, d.f.walkTopDown().filter { it.isFile }.sumOf { it.length() })
                }
            }
            AlertDialog(onDismissRequest = { dlg = null }, title = { Text("Information") },
                text = {
                    Text("Name: ${d.f.name}\nPath: ${d.f.path}\nType: ${if (d.f.isDirectory) "Folder" else d.f.extension.ifEmpty { "File" }}\n" +
                        "Size: $size\nModified: ${DateFormat.getDateTimeInstance().format(Date(d.f.lastModified()))}")
                },
                confirmButton = { TextButton({ dlg = null }) { Text("OK") } })
        }
        is Dlg.View -> {
            val names by produceState<List<String>?>(null, d) {
                value = withContext(Dispatchers.IO) { runCatching { Archiver.list(d.f) }.getOrElse { listOf("Cannot read: ${it.message}") } }
            }
            AlertDialog(onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1) },
                text = {
                    if (names == null) Text("Reading...") else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                        items(names!!.take(500)) { Text(it, fontSize = 13.sp, color = Dim, modifier = Modifier.padding(vertical = 2.dp)) }
                    }
                },
                confirmButton = { TextButton({ dlg = null }) { Text("Close") } })
        }
        Dlg.Shizuku -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Shizuku") },
            text = { Text(shizukuState() + "\n\nStart Shizuku, then tap Connect to grant AkFileCl permission.") },
            confirmButton = {
                TextButton({
                    runCatching {
                        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                            Shizuku.requestPermission(100)
                        else if (!Shizuku.pingBinder())
                            ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
                    }
                    dlg = null
                }) { Text("Connect") }
            },
            dismissButton = { TextButton({ dlg = null }) { Text("Close") } })
        Dlg.Favs -> ModalBottomSheet(onDismissRequest = { dlg = null }, containerColor = Panel) {
            Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding()) {
                SheetTitle("Favorites")
                if (favs.isEmpty()) Text("Long-press a folder and choose Add to Favorites.", color = Dim, modifier = Modifier.padding(16.dp))
                favs.sorted().forEach { p ->
                    Row(Modifier.fillMaxWidth().combinedClickable(onClick = { dir = File(p); dlg = null })
                        .padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Star, null, tint = Accent)
                        Spacer(Modifier.width(16.dp))
                        Text(p, color = Txt, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton({ setFavs(favs - p) }) { Icon(Icons.Filled.Close, "Remove", tint = Dim) }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showCredit) CreditPopup { showCredit = false }
}

@Composable
private fun SheetTitle(t: String) {
    Text(t, color = Txt, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
    HorizontalDivider(color = Accent.copy(alpha = 0.4f))
}

@Composable
private fun MenuItem(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().combinedClickableSimple(onClick).padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Txt)
        Spacer(Modifier.width(20.dp))
        Text(text, color = Txt, fontSize = 17.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.combinedClickableSimple(onClick: () -> Unit) = this.combinedClickable(onClick = onClick)

@Composable
private fun TextDlg(title: String, init: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(init) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true) },
        confirmButton = { TextButton({ onOk(t.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CompressDlg(f: File, onDismiss: () -> Unit, onOk: (String, String) -> Unit) {
    var name by remember { mutableStateOf(if (f.isDirectory) f.name else f.nameWithoutExtension) }
    var fmt by remember { mutableStateOf("zip") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Compress") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Archive name") })
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("zip", "7z", "tar").forEach {
                        FilterChip(selected = fmt == it, onClick = { fmt = it }, label = { Text(".$it") })
                    }
                }
            }
        },
        confirmButton = { TextButton({ if (name.isNotBlank()) onOk(name.trim(), fmt) }) { Text("Compress") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
private fun CreditPopup(onClose: () -> Unit) {
    var off by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxWidth().padding(24.dp)
                .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = { if (abs(off.x) > 250f || abs(off.y) > 250f) onClose() else off = Offset.Zero },
                        onDragCancel = { off = Offset.Zero }
                    ) { change, drag -> change.consume(); off += drag }
                }
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Box(Modifier.fillMaxWidth()) {
                    IconButton(onClose, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Filled.Close, "Close", tint = Txt) }
                    Column(Modifier.padding(horizontal = 28.dp).padding(top = 48.dp, bottom = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("AkFileCl", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(20.dp))
                        Text("Thank for using this app (AkFileCl)", color = Txt, fontSize = 17.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Text("Please kept the right to us Borath Sovannroth and Claude (our goat \uD83E\uDD79)",
                            color = Txt, fontSize = 17.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(20.dp))
                        Text("Tap ✕ or swipe away to close", color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
